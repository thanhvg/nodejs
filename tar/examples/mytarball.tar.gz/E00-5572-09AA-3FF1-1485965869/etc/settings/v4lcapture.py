# Copyright (c) 2002-2015 Userful Corporation. All rights reserved.
# http://www.userful.com/

"""This file defines the supported hdmi capure cards and their
supported modes"""

NORMS = [
    {
        "modes": [
            "0: none",
            "45056: NTSC",
            "4096: NTSC-M",
            "8192: NTSC-M-JP",
            "32768: NTSC-M-KR",
            "16384: NTSC-443",
            "255: PAL",
            "7: PAL-BG",
            "1: PAL-B",
            "2: PAL-B1",
            "4: PAL-G",
            "8: PAL-H",
            "16: PAL-I",
            "224: PAL-DK",
            "32: PAL-D",
            "64: PAL-D1",
            "128: PAL-K",
            "256: PAL-M",
            "512: PAL-N",
            "1024: PAL-Nc",
            "2048: PAL-60",
            "16711680: SECAM",
            "65536: SECAM-B",
            "262144: SECAM-G",
            "524288: SECAM-H",
            "3276800: SECAM-DK",
            "131072: SECAM-D",
            "1048576: SECAM-K",
            "2097152: SECAM-K1",
            "4194304: SECAM-L",
            "8388608: SECAM-Lc",
        ]
    }
]
