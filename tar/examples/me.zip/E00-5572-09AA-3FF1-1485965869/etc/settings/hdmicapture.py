# Copyright (c) 2002-2015 Userful Corporation. All rights reserved.
# http://www.userful.com/

"""This file defines the supported hdmi capure cards and their
supported modes"""

DEVICES = [
    {
        "modes": [
            "0: Automatic detection",
            "1: NTSC SD 60i",
            "2: NTSC SD 60i (24 fps)",
            "3: PAL SD 50i",
            "4: NTSC SD 60p",
            "5: PAL SD 50p",
            "17: HD720 50p",
            "18: HD720 59.94p",
            "19: HD720 60p",
            "11: HD1080 50i",
            "12: HD1080 59.94i",
            "13: HD1080 60i",
            "6: HD1080 23.98p",
            "7: HD1080 24p",
            "8: HD1080 25p",
            "9: HD1080 29.97p",
            "10: HD1080 30p",
            "14: HD1080 50p",
            "15: HD1080 59.94p",
            "16: HD1080 60p",
            "20: 2k 23.98p",
            "21: 2k 24p",
            "22: 2k 25p",
            "23: 4k 23.98p",
            "24: 4k 24p",
            "25: 4k 25p",
            "26: 4k 29.97p",
            "27: 4k 30p",
        ]
    }
]
